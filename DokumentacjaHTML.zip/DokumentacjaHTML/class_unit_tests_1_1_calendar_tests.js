var class_unit_tests_1_1_calendar_tests =
[
    [ "Test_IsJokeSingle", "class_unit_tests_1_1_calendar_tests.html#a2646bca8db7120636b407aca4970acab", null ],
    [ "Test_JokeWithoutError", "class_unit_tests_1_1_calendar_tests.html#aa54d7b07ae39a91775bd7ce03339d56d", null ],
    [ "Test_Proper_Day", "class_unit_tests_1_1_calendar_tests.html#a4fddc1eec56fc6a47eeacd50b34b2b11", null ],
    [ "Test_Proper_Month", "class_unit_tests_1_1_calendar_tests.html#af20f7aea706c4eed30d56bf59f74e239", null ],
    [ "Test_Proper_Year", "class_unit_tests_1_1_calendar_tests.html#ab07f2e4e0c073f7b278c4b2255e8a7cd", null ],
    [ "Test_String_Proper_Length", "class_unit_tests_1_1_calendar_tests.html#a985c31de699a08410bce3c477d36cd54", null ],
    [ "Test_TextNotNull_ReturnTrue", "class_unit_tests_1_1_calendar_tests.html#afca3747fbd59a8b0ece1a3605aad16db", null ],
    [ "Test_TextNull_ReturnFalse", "class_unit_tests_1_1_calendar_tests.html#aef81a1d3a5edf9fb93d74fa8fd1389d2", null ]
];