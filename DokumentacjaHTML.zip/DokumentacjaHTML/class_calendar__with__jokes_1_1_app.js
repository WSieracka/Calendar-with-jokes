var class_calendar__with__jokes_1_1_app =
[
    [ "InitializeComponent", "class_calendar__with__jokes_1_1_app.html#a6dc9a550febe232a6677fb19963d7331", null ],
    [ "InitializeComponent", "class_calendar__with__jokes_1_1_app.html#a6dc9a550febe232a6677fb19963d7331", null ]
];