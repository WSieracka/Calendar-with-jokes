var class_calendar__with__jokes_1_1_week_control =
[
    [ "WeekControl", "class_calendar__with__jokes_1_1_week_control.html#ae235d73b9b3f759d8eb07a35c4044b13", null ],
    [ "InitializeComponent", "class_calendar__with__jokes_1_1_week_control.html#a037add1e179e8cc1306a72ca220df23d", null ],
    [ "InitializeComponent", "class_calendar__with__jokes_1_1_week_control.html#a037add1e179e8cc1306a72ca220df23d", null ]
];