var namespace_app_tests =
[
    [ "Tests", "class_app_tests_1_1_tests.html", "class_app_tests_1_1_tests" ]
];