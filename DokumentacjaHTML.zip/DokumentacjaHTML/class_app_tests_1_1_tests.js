var class_app_tests_1_1_tests =
[
    [ "Setup", "class_app_tests_1_1_tests.html#a3fd99961fa036bcb11962e3c7e0635e9", null ],
    [ "Test1", "class_app_tests_1_1_tests.html#a631c5e4b7c1560e3ea1ac8b5a2c401ff", null ]
];