var class_api_library_1_1_joke_model =
[
    [ "delivery", "class_api_library_1_1_joke_model.html#af2672c104289f16a7e0155c1bdc526dc", null ],
    [ "error", "class_api_library_1_1_joke_model.html#a850a2e796334415efd5daa8a2af39288", null ],
    [ "Joke", "class_api_library_1_1_joke_model.html#a2b2e3c4b1dce1948398ef9352488a515", null ],
    [ "setup", "class_api_library_1_1_joke_model.html#ac18bc4d4f2dd3161aa183f3de664e686", null ],
    [ "type", "class_api_library_1_1_joke_model.html#a57724b1d885926abdd1cf479c8290eb6", null ]
];