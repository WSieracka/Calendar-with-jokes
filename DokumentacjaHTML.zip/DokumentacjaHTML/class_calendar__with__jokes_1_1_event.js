var class_calendar__with__jokes_1_1_event =
[
    [ "Event", "class_calendar__with__jokes_1_1_event.html#a15ccb92a42111ca76da021a7d41fb57f", null ],
    [ "Event", "class_calendar__with__jokes_1_1_event.html#a0324bd1f7e01b4bf42f8e6f32f738758", null ],
    [ "Day", "class_calendar__with__jokes_1_1_event.html#a3ff3fff435653e540281bd487eddb7bb", null ],
    [ "Description", "class_calendar__with__jokes_1_1_event.html#a86cd235c088518b03259ae0457404951", null ],
    [ "EventID", "class_calendar__with__jokes_1_1_event.html#a2fdd4cc90defccda64119a5bbc7203ab", null ],
    [ "Kind", "class_calendar__with__jokes_1_1_event.html#a6f1779082cea3305df0e6afb3cf3af8c", null ],
    [ "Month", "class_calendar__with__jokes_1_1_event.html#aedc4bea37e7581af9452da25fedab5c7", null ],
    [ "Name", "class_calendar__with__jokes_1_1_event.html#acd4f7882d423e2efc8688f53584e10c8", null ],
    [ "Year", "class_calendar__with__jokes_1_1_event.html#a08af3071f4808cb78705021780813566", null ]
];