var namespace_api_library =
[
    [ "JokeModel", "class_api_library_1_1_joke_model.html", "class_api_library_1_1_joke_model" ],
    [ "JokeProcessor", "class_api_library_1_1_joke_processor.html", null ]
];