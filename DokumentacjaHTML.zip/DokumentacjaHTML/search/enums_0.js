var searchData=
[
  ['updateorderoption_121',['UpdateOrderOption',['../class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a02ccd7196e6ab326f3cf991bcefc3c6d',1,'Calendar_with_jokes::CalendarDataSetTableAdapters::TableAdapterManager']]]
];
