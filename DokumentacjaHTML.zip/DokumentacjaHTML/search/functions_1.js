var searchData=
[
  ['b_5ffirst_5fclick_97',['b_first_Click',['../class_calendar__with__jokes_1_1_main_window.html#a611c2a307bf01fa8d1802a860023a117',1,'Calendar_with_jokes::MainWindow']]]
];
