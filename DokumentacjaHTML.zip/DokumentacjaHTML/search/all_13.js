var searchData=
[
  ['year_67',['Year',['../class_calendar__with__jokes_1_1_event.html#a08af3071f4808cb78705021780813566',1,'Calendar_with_jokes::Event']]],
  ['year_68',['year',['../class_calendar__with__jokes_1_1_day_control.html#ac151e233f5d28c40948c8debff579ed9',1,'Calendar_with_jokes::DayControl']]]
];
