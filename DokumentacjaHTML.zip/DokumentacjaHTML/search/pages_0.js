var searchData=
[
  ['license_143',['LICENSE',['../md__c___users_sebas_source_repos__calendar_with_jokes_packages__newtonsoft__json_13_0_1__l_i_c_e_n_s_e.html',1,'']]]
];
