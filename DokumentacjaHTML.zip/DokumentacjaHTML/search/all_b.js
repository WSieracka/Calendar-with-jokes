var searchData=
[
  ['name_52',['Name',['../class_calendar__with__jokes_1_1_event.html#acd4f7882d423e2efc8688f53584e10c8',1,'Calendar_with_jokes::Event']]],
  ['nunit_203_2e13_2e2_20_2d_20april_2027_2c_202021_53',['NUnit 3.13.2 - April 27, 2021',['../md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html',1,'']]]
];
