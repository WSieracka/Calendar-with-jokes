var searchData=
[
  ['name_137',['Name',['../class_calendar__with__jokes_1_1_event.html#acd4f7882d423e2efc8688f53584e10c8',1,'Calendar_with_jokes::Event']]]
];
