var searchData=
[
  ['unittests_61',['UnitTests',['../namespace_unit_tests.html',1,'']]],
  ['updateall_62',['UpdateAll',['../class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a2d8baa156863222c5751d50894a8be1a',1,'Calendar_with_jokes::CalendarDataSetTableAdapters::TableAdapterManager']]],
  ['updateorderoption_63',['UpdateOrderOption',['../class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a02ccd7196e6ab326f3cf991bcefc3c6d',1,'Calendar_with_jokes::CalendarDataSetTableAdapters::TableAdapterManager']]]
];
