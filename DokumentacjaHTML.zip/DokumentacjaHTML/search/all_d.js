var searchData=
[
  ['setpropertyvalue_55',['SetPropertyValue',['../class_xaml_generated_namespace_1_1_generated_internal_type_helper.html#ade0f04c0f7b18dd5b170e071d5534d38',1,'XamlGeneratedNamespace::GeneratedInternalTypeHelper']]],
  ['setup_56',['setup',['../class_api_library_1_1_joke_model.html#ac18bc4d4f2dd3161aa183f3de664e686',1,'ApiLibrary::JokeModel']]],
  ['showevents_57',['ShowEvents',['../class_calendar__with__jokes_1_1_view_day.html#a30eb3a57a5c456a66f98b1a477d500de',1,'Calendar_with_jokes::ViewDay']]]
];
