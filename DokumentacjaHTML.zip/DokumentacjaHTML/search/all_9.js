var searchData=
[
  ['license_46',['LICENSE',['../md__c___users_sebas_source_repos__calendar_with_jokes_packages__newtonsoft__json_13_0_1__l_i_c_e_n_s_e.html',1,'']]],
  ['loadjoke_47',['LoadJoke',['../class_api_library_1_1_joke_processor.html#a9e6f03816cb8fee77bcdc2a2c17a423c',1,'ApiLibrary::JokeProcessor']]]
];
