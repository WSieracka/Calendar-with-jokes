var searchData=
[
  ['calendar_5fwith_5fjokes_91',['Calendar_with_jokes',['../namespace_calendar__with__jokes.html',1,'']]],
  ['calendardatasettableadapters_92',['CalendarDataSetTableAdapters',['../namespace_calendar__with__jokes_1_1_calendar_data_set_table_adapters.html',1,'Calendar_with_jokes']]],
  ['properties_93',['Properties',['../namespace_calendar__with__jokes_1_1_properties.html',1,'Calendar_with_jokes']]]
];
