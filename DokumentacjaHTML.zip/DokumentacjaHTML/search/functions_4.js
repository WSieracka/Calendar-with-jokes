var searchData=
[
  ['event_105',['Event',['../class_calendar__with__jokes_1_1_event.html#a15ccb92a42111ca76da021a7d41fb57f',1,'Calendar_with_jokes.Event.Event()'],['../class_calendar__with__jokes_1_1_event.html#a0324bd1f7e01b4bf42f8e6f32f738758',1,'Calendar_with_jokes.Event.Event(int eventID, string name, string kind, string description, int year, int month, int day)']]],
  ['eventcontrol_106',['EventControl',['../class_calendar__with__jokes_1_1_event_control.html#a440d7e133ff5fc12416ec9cd7a8c3969',1,'Calendar_with_jokes::EventControl']]]
];
