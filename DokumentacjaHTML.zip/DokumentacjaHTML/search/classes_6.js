var searchData=
[
  ['mainwindow_84',['MainWindow',['../class_calendar__with__jokes_1_1_main_window.html',1,'Calendar_with_jokes']]]
];
