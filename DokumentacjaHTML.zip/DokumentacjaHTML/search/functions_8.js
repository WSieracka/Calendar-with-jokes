var searchData=
[
  ['main_114',['Main',['../class_calendar__with__jokes_1_1_app.html#aff9d48f3ab1d3f9bd3fee904f04a61da',1,'Calendar_with_jokes.App.Main()'],['../class_calendar__with__jokes_1_1_app.html#aff9d48f3ab1d3f9bd3fee904f04a61da',1,'Calendar_with_jokes.App.Main()']]],
  ['mainwindow_115',['MainWindow',['../class_calendar__with__jokes_1_1_main_window.html#a04d0363d160eaa4c17d91be60c0671f8',1,'Calendar_with_jokes::MainWindow']]]
];
