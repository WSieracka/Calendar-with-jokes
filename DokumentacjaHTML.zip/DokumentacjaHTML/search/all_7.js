var searchData=
[
  ['joke_42',['Joke',['../class_api_library_1_1_joke_model.html#a2b2e3c4b1dce1948398ef9352488a515',1,'ApiLibrary::JokeModel']]],
  ['jokemodel_43',['JokeModel',['../class_api_library_1_1_joke_model.html',1,'ApiLibrary']]],
  ['jokeprocessor_44',['JokeProcessor',['../class_api_library_1_1_joke_processor.html',1,'ApiLibrary']]]
];
