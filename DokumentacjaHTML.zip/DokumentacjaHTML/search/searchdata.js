var indexSectionsWithContent =
{
  0: "abcdegijklmnpstuvwxy",
  1: "acdegjmtvw",
  2: "acux",
  3: "abcdegilmsuvw",
  4: "u",
  5: "adejkmnsty",
  6: "p",
  7: "ln"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "namespaces",
  3: "functions",
  4: "enums",
  5: "properties",
  6: "events",
  7: "pages"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Namespaces",
  3: "Functions",
  4: "Enumerations",
  5: "Properties",
  6: "Events",
  7: "Pages"
};

