var searchData=
[
  ['propertychanged_142',['PropertyChanged',['../class_calendar__with__jokes_1_1_view_day.html#aee143c9f27f12e18c63ab3f2696f3a91',1,'Calendar_with_jokes::ViewDay']]]
];
