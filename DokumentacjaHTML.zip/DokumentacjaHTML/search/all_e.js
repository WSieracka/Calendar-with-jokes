var searchData=
[
  ['tableadaptermanager_58',['TableAdapterManager',['../class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html',1,'Calendar_with_jokes::CalendarDataSetTableAdapters']]],
  ['tests_59',['Tests',['../class_app_tests_1_1_tests.html',1,'AppTests']]],
  ['type_60',['type',['../class_api_library_1_1_joke_model.html#a57724b1d885926abdd1cf479c8290eb6',1,'ApiLibrary::JokeModel']]]
];
