var searchData=
[
  ['tableadaptermanager_85',['TableAdapterManager',['../class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html',1,'Calendar_with_jokes::CalendarDataSetTableAdapters']]],
  ['tests_86',['Tests',['../class_app_tests_1_1_tests.html',1,'AppTests']]]
];
