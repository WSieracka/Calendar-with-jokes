var searchData=
[
  ['day_125',['day',['../class_calendar__with__jokes_1_1_day_control.html#aec30ab18ad6209037a0ce80e03fc233b',1,'Calendar_with_jokes::DayControl']]],
  ['day_126',['Day',['../class_calendar__with__jokes_1_1_event.html#a3ff3fff435653e540281bd487eddb7bb',1,'Calendar_with_jokes::Event']]],
  ['delivery_127',['delivery',['../class_api_library_1_1_joke_model.html#af2672c104289f16a7e0155c1bdc526dc',1,'ApiLibrary::JokeModel']]],
  ['description_128',['Description',['../class_calendar__with__jokes_1_1_event.html#a86cd235c088518b03259ae0457404951',1,'Calendar_with_jokes::Event']]]
];
