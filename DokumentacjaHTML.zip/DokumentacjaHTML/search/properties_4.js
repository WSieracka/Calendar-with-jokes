var searchData=
[
  ['kind_134',['Kind',['../class_calendar__with__jokes_1_1_event.html#a6f1779082cea3305df0e6afb3cf3af8c',1,'Calendar_with_jokes::Event']]]
];
