var searchData=
[
  ['jokemodel_82',['JokeModel',['../class_api_library_1_1_joke_model.html',1,'ApiLibrary']]],
  ['jokeprocessor_83',['JokeProcessor',['../class_api_library_1_1_joke_processor.html',1,'ApiLibrary']]]
];
