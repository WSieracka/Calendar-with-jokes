var class_calendar__with__jokes_1_1_event_control =
[
    [ "EventControl", "class_calendar__with__jokes_1_1_event_control.html#a440d7e133ff5fc12416ec9cd7a8c3969", null ],
    [ "InitializeComponent", "class_calendar__with__jokes_1_1_event_control.html#ab57ce0f1d99b0d97b179a76e9c5840cb", null ],
    [ "InitializeComponent", "class_calendar__with__jokes_1_1_event_control.html#ab57ce0f1d99b0d97b179a76e9c5840cb", null ]
];