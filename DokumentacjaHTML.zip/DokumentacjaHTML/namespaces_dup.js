var namespaces_dup =
[
    [ "ApiLibrary", "namespace_api_library.html", "namespace_api_library" ],
    [ "AppTests", "namespace_app_tests.html", "namespace_app_tests" ],
    [ "Calendar_with_jokes", "namespace_calendar__with__jokes.html", "namespace_calendar__with__jokes" ],
    [ "UnitTests", "namespace_unit_tests.html", "namespace_unit_tests" ],
    [ "XamlGeneratedNamespace", "namespace_xaml_generated_namespace.html", "namespace_xaml_generated_namespace" ]
];