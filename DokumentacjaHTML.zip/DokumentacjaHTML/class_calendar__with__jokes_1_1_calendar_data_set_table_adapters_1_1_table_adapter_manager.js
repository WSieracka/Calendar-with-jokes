var class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager =
[
    [ "UpdateOrderOption", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a02ccd7196e6ab326f3cf991bcefc3c6d", [
      [ "InsertUpdateDelete", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a02ccd7196e6ab326f3cf991bcefc3c6da27b77cb15d3da7ded0250d0001bc6755", null ],
      [ "UpdateInsertDelete", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a02ccd7196e6ab326f3cf991bcefc3c6da894fcc001e51f673d3fb5f3096473dd8", null ]
    ] ],
    [ "MatchTableAdapterConnection", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#aaab6a8496966e4aa47dde4a839b491ab", null ],
    [ "SortSelfReferenceRows", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a754c181db6fc99a26337482166995747", null ],
    [ "UpdateAll", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a2d8baa156863222c5751d50894a8be1a", null ],
    [ "BackupDataSetBeforeUpdate", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a5fca8c977eca6ccc80ef6aeb30b00145", null ],
    [ "Connection", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#a182b7fbd00c147e2cf914d2d73bb0e1f", null ],
    [ "EventsTableAdapter", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#aecf2f80fc1830d53e48e3a2554c95f8c", null ],
    [ "TableAdapterInstanceCount", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#ad79373adab3f6db3edb45f657496c2a9", null ],
    [ "UpdateOrder", "class_calendar__with__jokes_1_1_calendar_data_set_table_adapters_1_1_table_adapter_manager.html#ad63eb09fd20a04be95b033f0893f4a3a", null ]
];