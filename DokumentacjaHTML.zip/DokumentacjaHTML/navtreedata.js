/*
 @licstart  The following is the entire license notice for the JavaScript code in this file.

 The MIT License (MIT)

 Copyright (C) 1997-2020 by Dimitri van Heesch

 Permission is hereby granted, free of charge, to any person obtaining a copy of this software
 and associated documentation files (the "Software"), to deal in the Software without restriction,
 including without limitation the rights to use, copy, modify, merge, publish, distribute,
 sublicense, and/or sell copies of the Software, and to permit persons to whom the Software is
 furnished to do so, subject to the following conditions:

 The above copyright notice and this permission notice shall be included in all copies or
 substantial portions of the Software.

 THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND
 NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM,
 DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

 @licend  The above is the entire license notice for the JavaScript code in this file
*/
var NAVTREE =
[
  [ "Calendar with Jokes", "index.html", [
    [ "LICENSE", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__newtonsoft__json_13_0_1__l_i_c_e_n_s_e.html", null ],
    [ "NUnit 3.13.2 - April 27, 2021", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html", [
      [ "NUnit 3.13.1 - January 31, 2021", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md2", [
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md1", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md3", null ]
      ] ],
      [ "NUnit 3.13 - January 7, 2021", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md4", [
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md5", null ],
        [ "NUnit 3.12 - May 14, 2019", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md6", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md7", null ],
        [ "NUnit 3.11 - October 6, 2018", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md8", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md9", null ],
        [ "NUnit 3.10.1 - March 12, 2018", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md10", null ],
        [ "NUnit 3.10 - March 12, 2018", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md11", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md12", null ],
        [ "NUnit 3.9 - November 10, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md13", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md14", null ],
        [ "NUnit 3.8.1 - August 28, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md15", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md16", null ],
        [ "NUnit 3.8 - August 27, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md17", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md18", null ],
        [ "NUnit 3.7.1 - June 6, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md19", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md20", null ],
        [ "NUnit 3.7 - May 29, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md21", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md22", null ],
        [ "NUnit 3.6.1 - February 26, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md23", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md24", null ],
        [ "NUnit 3.6 - January 9, 2017", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md25", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md26", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md27", null ],
        [ "NUnit 3.5 - October 3, 2016", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md28", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md29", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md30", null ],
        [ "NUnit 3.4.1 - June 30, 2016", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md31", null ],
        [ "Console Runner", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md32", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md33", null ],
        [ "NUnit 3.4 - June 25, 2016", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md34", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md35", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md36", null ],
        [ "Console Runner", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md37", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md38", null ],
        [ "NUnit 3.2.1 - April 19, 2016", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md39", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md40", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md41", null ],
        [ "Console Runner", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md42", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md43", null ],
        [ "NUnit 3.2 - March 5, 2016", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md44", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md45", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md46", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md47", null ],
        [ "NUnit 3.0.1 - December 1, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md48", null ],
        [ "Console Runner", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md49", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md50", null ],
        [ "NUnit 3.0.0 Final Release - November 15, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md51", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md52", null ],
        [ "NUnit 3.0.0 Release Candidate 3 - November 13, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md53", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md54", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md55", null ],
        [ "NUnit 3.0.0 Release Candidate 2 - November 8, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md56", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md57", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md58", null ],
        [ "NUnit 3.0.0 Release Candidate - November 1, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md59", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md60", null ],
        [ "NUnitLite", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md61", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md62", null ],
        [ "Console Runner", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md63", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md64", null ],
        [ "NUnit 3.0.0 Beta 5 - October 16, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md65", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md66", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md67", null ],
        [ "Console Runner", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md68", [
          [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md69", null ]
        ] ],
        [ "NUnit 3.0.0 Beta 4 - August 25, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md70", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md71", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md72", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md73", null ],
        [ "NUnit 3.0.0 Beta 3 - July 15, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md74", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md75", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md76", null ],
        [ "Console", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md77", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md78", null ],
        [ "NUnit 3.0.0 Beta 2 - May 12, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md79", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md80", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md81", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md82", null ],
        [ "NUnit 3.0.0 Beta 1 - March 25, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md83", null ],
        [ "General", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md84", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md85", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md86", null ],
        [ "Console", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md87", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md88", null ],
        [ "NUnit 3.0.0 Alpha 5 - January 30, 2015", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md89", null ],
        [ "General", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md90", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md91", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md92", null ],
        [ "Console", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md93", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md94", null ],
        [ "NUnit 3.0.0 Alpha 4 - December 30, 2014", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md95", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md96", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md97", null ],
        [ "Console", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md98", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md99", null ],
        [ "NUnit 3.0.0 Alpha 3 - November 29, 2014", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md100", null ],
        [ "Breaking Changes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md101", null ],
        [ "Framework", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md102", null ],
        [ "Engine", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md103", null ],
        [ "Console", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md104", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md105", null ],
        [ "NUnit 3.0.0 Alpha 2 - November 2, 2014", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md106", null ],
        [ "Breaking Changes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md107", null ],
        [ "General", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md108", null ],
        [ "New Features", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md109", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md110", null ],
        [ "NUnit 3.0.0 Alpha 1 - September 22, 2014", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md111", null ],
        [ "Breaking Changes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md112", null ],
        [ "General", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md113", null ],
        [ "New Features", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md114", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md115", null ],
        [ "Console Issues Resolved (Old nunit-console project, now combined with nunit)", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md116", null ],
        [ "NUnit 2.9.7 - August 8, 2014", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md117", null ],
        [ "Breaking Changes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md118", null ],
        [ "New Features", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md119", null ],
        [ "Issues Resolved", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md120", null ],
        [ "NUnit 2.9.6 - October 4, 2013", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md121", null ],
        [ "Main Features", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md122", null ],
        [ "Bug Fixes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md123", null ],
        [ "Bug Fixes in 2.9.6 But Not Listed Here in the Release", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md124", null ],
        [ "NUnit 2.9.5 - July 30, 2010", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md125", null ],
        [ "Bug Fixes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md126", null ],
        [ "NUnit 2.9.4 - May 4, 2010", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md127", null ],
        [ "Bug Fixes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md128", null ],
        [ "NUnit 2.9.3 - October 26, 2009", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md129", null ],
        [ "Main Features", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md130", null ],
        [ "Bug Fixes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md131", null ],
        [ "NUnit 2.9.2 - September 19, 2009", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md132", null ],
        [ "Main Features", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md133", null ],
        [ "Bug Fixes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md134", null ],
        [ "NUnit 2.9.1 - August 27, 2009", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md135", null ],
        [ "General", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md136", null ],
        [ "Bug Fixes", "md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md137", null ]
      ] ]
    ] ],
    [ "Packages", "namespaces.html", [
      [ "Packages", "namespaces.html", "namespaces_dup" ]
    ] ],
    [ "Classes", "annotated.html", [
      [ "Class List", "annotated.html", "annotated_dup" ],
      [ "Class Index", "classes.html", null ],
      [ "Class Hierarchy", "hierarchy.html", "hierarchy" ],
      [ "Class Members", "functions.html", [
        [ "All", "functions.html", null ],
        [ "Functions", "functions_func.html", null ],
        [ "Enumerations", "functions_enum.html", null ],
        [ "Properties", "functions_prop.html", null ],
        [ "Events", "functions_evnt.html", null ]
      ] ]
    ] ]
  ] ]
];

var NAVTREEINDEX =
[
"annotated.html",
"md__c___users_sebas_source_repos__calendar_with_jokes_packages__n_unit_3_13_2__c_h_a_n_g_e_s.html#autotoc_md44"
];

var SYNCONMSG = 'click to disable panel synchronisation';
var SYNCOFFMSG = 'click to enable panel synchronisation';