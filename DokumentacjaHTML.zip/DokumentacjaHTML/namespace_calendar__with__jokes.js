var namespace_calendar__with__jokes =
[
    [ "CalendarDataSetTableAdapters", "namespace_calendar__with__jokes_1_1_calendar_data_set_table_adapters.html", "namespace_calendar__with__jokes_1_1_calendar_data_set_table_adapters" ],
    [ "Properties", "namespace_calendar__with__jokes_1_1_properties.html", null ],
    [ "App", "class_calendar__with__jokes_1_1_app.html", "class_calendar__with__jokes_1_1_app" ],
    [ "CalendarDataSet", "class_calendar__with__jokes_1_1_calendar_data_set.html", "class_calendar__with__jokes_1_1_calendar_data_set" ],
    [ "CalendarEntities2", "class_calendar__with__jokes_1_1_calendar_entities2.html", "class_calendar__with__jokes_1_1_calendar_entities2" ],
    [ "DayControl", "class_calendar__with__jokes_1_1_day_control.html", "class_calendar__with__jokes_1_1_day_control" ],
    [ "Event", "class_calendar__with__jokes_1_1_event.html", "class_calendar__with__jokes_1_1_event" ],
    [ "EventControl", "class_calendar__with__jokes_1_1_event_control.html", "class_calendar__with__jokes_1_1_event_control" ],
    [ "MainWindow", "class_calendar__with__jokes_1_1_main_window.html", "class_calendar__with__jokes_1_1_main_window" ],
    [ "ViewDay", "class_calendar__with__jokes_1_1_view_day.html", "class_calendar__with__jokes_1_1_view_day" ],
    [ "WeekControl", "class_calendar__with__jokes_1_1_week_control.html", "class_calendar__with__jokes_1_1_week_control" ]
];