var class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row =
[
    [ "IsDescriptionNull", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#a5f63e885ba3dab9c49de1888beae1bac", null ],
    [ "IsKindNull", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#ab5caf788600e24718d07014567c79510", null ],
    [ "SetDescriptionNull", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#ab3008d7eb32cd447c9a0c5331d744d87", null ],
    [ "SetKindNull", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#a1cc0d2dae839346721bc8847579b4fd0", null ],
    [ "Date", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#aa428e12176dc8224dd2c8f9bf9cb4491", null ],
    [ "Description", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#a748baf46cf9b3dc021ed68b72acb3999", null ],
    [ "EventID", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#a35e6bb4b4b7c47c2bc7c9ce433e37e93", null ],
    [ "Kind", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#acf98072e064ee111d53bf870047066fc", null ],
    [ "Name", "class_calendar__with__jokes_1_1_calendar_data_set_1_1_events_row.html#a12e12c7965722632b389c67434f00c1a", null ]
];